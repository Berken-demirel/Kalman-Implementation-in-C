//==============================================================================
//
// Title:		Include File.h
// Purpose:		A short description of the interface.
//
// Created on:	2.5.2020 at 22:15:24 by Utku Demirel.
// Copyright:	Middle East Technical University. All Rights Reserved.
//
//==============================================================================

#ifndef __IncludeFile_H__
#define __IncludeFile_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#include "cvidef.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// External variables

//==============================================================================
// Global functions

void my_kalman (int measured_x, int measured_y, double *P[4][4], int *X[4][1], int *output[2]);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __IncludeFile_H__ */
